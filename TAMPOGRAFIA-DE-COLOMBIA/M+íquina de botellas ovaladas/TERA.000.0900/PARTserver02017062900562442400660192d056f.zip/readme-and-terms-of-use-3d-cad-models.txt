﻿
ES   Download de 29.06.2017 desde PARTcommunity/PARTserver:

       Estimado Usuario,
       
       adjunto los siguientes archivos de nuestro portal de download de modelos CAD 3D PARTcommunity/PARTserver
       powered by CADENAS:

       
	   
       SOLIDWORKS, GRB11212x180-UB15_Open-Extend, _BODY_GRB11_2_12x180_UB15_Open_Extend_2.sldprt
       SOLIDWORKS, GRB11212x180-UB15_Open-Extend, _PIN_GRB12_7.sldprt
       SOLIDWORKS, GRB11212x180-UB15_Open-Extend, GRB11212x180_UB15_Open_Extend.sldasm
       SOLIDWORKS, GRB11212x180-UB15_Open-Extend, _JAW_GRB012_4.sldprt
       IGES, GRB11212x180-UB15_Open-Extend, GRB11212x180-UB15_Open-Extend.igs
       PDFDATASHEET, GRB11212x180-UB15_Open-Extend, GRB11212x180-UB15_Open-Extend.pdf
       SOLIDWORKS, GRB11212x180-UB15_Closed-Retract, _JAW_GRB012_4.sldprt
       SOLIDWORKS, GRB11212x180-UB15_Closed-Retract, _PIN_GRB12_7.sldprt
       SOLIDWORKS, GRB11212x180-UB15_Closed-Retract, _BODY_GRB11_2_12x180_UB15_Closed_Retract_2.sldprt
       SOLIDWORKS, GRB11212x180-UB15_Closed-Retract, GRB11212x180_UB15_Closed_Retract.sldasm
       IGES, GRB11212x180-UB15_Closed-Retract, GRB11212x180-UB15_Closed-Retract.igs
       PDFDATASHEET, GRB11212x180-UB15_Closed-Retract, GRB11212x180-UB15_Closed-Retract.pdf
	
       Indicaciones para el uso:

       
       El anexo ha sido comprimido ("ZIP") para poder descargarlo más rápidamente.
       Para abrir el archivo se necesita un programa informático para descomprimir los archivos. 

       Si no se dispone de un software para la extracción de archivos, es posible descargarlo  desde los
       siguientes enlaces: PKZip® (http://www.pkware.com) o WinZip® (http://www.winzip.com)

       

       Please also check terms of use at http://www.cadenas.de/terms-of-use-3d-cad-models
       

       Atentamente

       CADENAS GmbH
       support@cadenas.de



       >> Aplicación gratuita para modelos CAD 3D <<
       
       Acceso móvil a los modelos CAD 3D desde vuestro Smartphone o Tablet PC. 
       
       Descargue ahora desde http://www.cadenas.de/en/app-store



       >> PARTcommunity - lLa plataforma de red  y información para los ingenieros <<
       
       ■ Ejemplos de uso e ideas para componentes
       ■ Intercambio de experiencias con otros ingenieros

       Participe en el debate en el sitio http://www.partcommunity.com
       
       
       
       